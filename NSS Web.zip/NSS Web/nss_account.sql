-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 27, 2020 at 07:56 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nss_account`
--

-- --------------------------------------------------------

--
-- Table structure for table `endorsed_forms`
--

CREATE TABLE IF NOT EXISTS `endorsed_forms` (
  `NSS_Number` varchar(20) NOT NULL,
  `Signature_img` varchar(20) NOT NULL,
  `Form No.` int(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Form No.`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `endorsed_forms`
--

INSERT INTO `endorsed_forms` (`NSS_Number`, `Signature_img`, `Form No.`) VALUES
('NSSGUG2345678', '5f1e0ae39cf16.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `issueform`
--

CREATE TABLE IF NOT EXISTS `issueform` (
  `Month` varchar(20) NOT NULL,
  `Year` varchar(20) NOT NULL,
  `deadline` date NOT NULL,
  `Issue-Form` varchar(3) NOT NULL DEFAULT 'Yes'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issueform`
--

INSERT INTO `issueform` (`Month`, `Year`, `deadline`, `Issue-Form`) VALUES
('January', '2020', '2020-01-31', 'Yes'),
('February', '2020', '2020-02-28', 'Yes'),
('March', '2020', '2020-03-31', 'Yes'),
('April', '2020', '2020-04-30', 'Yes'),
('May', '2020', '2020-05-31', 'Yes'),
('June', '2020', '2020-07-31', 'Yes'),
('July', '2020', '2020-07-31', 'Yes'),
('August', '2020', '2020-08-31', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `personnel_info`
--

CREATE TABLE IF NOT EXISTS `personnel_info` (
  `Acc_Number` int(20) NOT NULL AUTO_INCREMENT,
  `surname` varchar(20) NOT NULL,
  `othername` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `institution` varchar(20) NOT NULL,
  `std_id` int(20) NOT NULL,
  `workplace` varchar(20) NOT NULL,
  `enumber` varchar(10) NOT NULL,
  `district` varchar(45) NOT NULL,
  `region` varchar(20) NOT NULL,
  `NSS_Number` varchar(20) NOT NULL,
  PRIMARY KEY (`Acc_Number`),
  UNIQUE KEY `NSS_Number` (`NSS_Number`),
  UNIQUE KEY `enumber` (`enumber`),
  UNIQUE KEY `std_id` (`std_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `personnel_info`
--

INSERT INTO `personnel_info` (`Acc_Number`, `surname`, `othername`, `dob`, `email`, `phone`, `password`, `institution`, `std_id`, `workplace`, `enumber`, `district`, `region`, `NSS_Number`) VALUES
(1, 'Atta-Fynn', 'Vanessa', '1999-09-21', 'vattafynn2020@gmail.com', '0552396246', 'Lmfao007', 'University Of Ghana ', 10665130, 'ABD Bank', '1234567891', 'La Nkwantanang Madina', 'Greater Accra', 'NSSGUG1234567'),
(2, 'Debrah', 'Andrew', '1999-08-03', 'debrahandraw@yahoo.com', '0558182836', 'andrew123', 'University Of Ghana ', 10674820, 'ABD Bank', '2345678912', 'La Nkwantanang Madina', 'Greater Accra', 'NSSGUG2345678'),
(3, 'Awuku', 'Esinam', '1999-12-03', 'jawuku33@gmail.com', '0507590892', 'esinam123', 'University Of Ghana ', 10683457, 'ABD Bank', '3456789123', 'La Nkwantanang Madina', 'Greater Accra', 'NSSGUG3456789'),
(4, 'Danso', 'Emmanuel', '1999-03-27', 'dansoemmanual@gmail.com', '0544638351', 'danso123', 'University Of Ghana ', 10662313, 'ABD Bank', '4567891234', 'La Nkwantanang Madina', 'Greater Accra', 'NSSGUG4567891'),
(5, 'Asamoah', 'Keziah', '1999-02-06', 'keziahasamoah@gmail.com', '0540644517', 'keziah123', 'University Of Ghana ', 10683434, 'ABD Bank', '5678912345', 'La Nkwantanang Madina', 'Greater Accra', 'NSSGUG5678912'),
(6, 'Elleah', 'Louis', '1999-02-06', 'louiselleah5@gmail.com', '0547465294', 'el123', 'University Of Ghana ', 10673455, 'ABD Bank', '6789123456', 'La Nkwantanang Madina', 'Greater Accra', 'NSSGUG6789123');

-- --------------------------------------------------------

--
-- Table structure for table `verified_forms`
--

CREATE TABLE IF NOT EXISTS `verified_forms` (
  `NSS_Number` varchar(20) NOT NULL,
  `Verified` varchar(5) NOT NULL DEFAULT 'No',
  `Form No.` int(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Form No.`),
  UNIQUE KEY `NSS_Number` (`NSS_Number`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `verified_forms`
--

INSERT INTO `verified_forms` (`NSS_Number`, `Verified`, `Form No.`) VALUES
('NSSGUG1234567', 'No', 1),
('NSSGUG2345678', 'Yes', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

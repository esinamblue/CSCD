<?php

	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'testdb';

	mysql_connect("localhost", "root", "Lmfao007");

	mysql_select_db($dbname);
	echo "Connected to db";






?>
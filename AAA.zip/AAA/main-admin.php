<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript" src="new-main.js"></script>


	<style type="text/css">
		

*{
	margin: 0;
	font-family: arial;
}

body{
	background-image: linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),url(bg1.jpg);
	background-position: center;
	background-size: cover;
	background-color:#4CAF50;
	height: 100%;	
}

.loginBox input[type=text] {
  width:65%;
  border-radius: 10px;
  background-color: silver;
  display: block;
  height:40px;
  border:none;
  border-radius:40px;
  font-size: 15px;
  font-family: arial;
  padding-left:20px;
} 


.loginBox input[type=password] {

  width:65%;
  border-radius: 10px;
  background-color: silver;
  display: block;
  height:40px;
  border:none;
  border-radius:40px;
  padding-left:20px;
  font-size: 15px;
  font-family: arial;

} 

input[type=radio]{
	/*float:left;
	margin-left:54px;*/
}

.loginBox button{
			background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:70%;
			height:40px;
			cursor: pointer;
			opacity:0.8;
}

button:hover{
	opacity:1;
} 



.loginBox{
	background-color: white;
	width:35%;
	height:600px;
	padding-top:5%;
	border-radius: 10px;
}

.Ash{
	background-color: silver;
	width:360px;
	height:60px;
	border-radius:10px;
	border:none;
}

i{
	background-color:silver;
	padding-top:19px;
	padding-right:15px;
}




	</style>

</head>
<body>
	<br><br>
	<center>
	<div class="loginBox">
		<img src="coat.jpg" id="img" style="height: 23%;width: 25%">
		<br><br><br>
			<p style="font-size:25px">Sign In As Administator</p><br><br><br><br>
			<form action="" method="get" >
				<input type="text" name="userID" placeholder="UserID" required><br><br>
				<input type="password" name="password" placeholder="Password" required>
				<br>
				<br><br><br><br>

				<button type="submit" name="submit" onclick="check(this.form)" class="button">Sign In</button>
			</form>

			<br>
			

	</div>
	</center>
</body>
</html>
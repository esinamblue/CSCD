function check(form) {
	if (form.userID.value == "NSS-Web-app" && form.password.value == "lmafo007")
	{
		window.open('home.html')
	}
	else{
		alert('userID and password do not match')
	}
}


function show(){
	var pswrd = document.getElementById('pswrd');
	var icon = document.querySelector('.fa');
	if(pswrd.type==="password"){
		pswrd.type = "text";
		//pswrd.style.marginTop = "20px";
		icon.style.color = "#141E30";
	} else {
		pswrd.type = "password";
		icon.style.color = "gray";
	}
}
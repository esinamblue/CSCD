<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="personnelstyle.css">
<style type="text/css">
		button {
		background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:80px;
			height:30px;
			cursor: pointer;
	}

	#Select {
		border-style: 2em;
		border-color:#900C3F;
		width: 200px;
		height:30px;
		border-radius: 10px;
	}

	.data{
		background-color:white;
		width:50px;
		height: 150px;
		text-align: center;
	}

	table{
		border-spacing:40px;

	}

	.data img{
		width:80px;
		height:90px;
	}
</style>	
</head>
<body>
	<header class="header1">

<ul style="">

	<li style="display:inline-block;float:left; padding-right:50px;padding-top:15px">
		<img src="NSS-logo.png" style="width:60px;height:40px">
	</li>



	<li style="display:inline-block;float:right; padding-right:10%;padding-top:25px">
		<select id="Select" name="Select">
					<option value="1">NSS Personnel</option>
					<option value="2">Supervisor</option>
					<option value="3">Administrator</option>
			</select>
			<button onclick="Display()">Submit</button>
	</li>


</ul>

</header>
	<div>
		
			

		<script type="text/javascript">

			function Display(){
			var s = document.getElementById('Select');

				if(s.value == "1"){
				window.open('new-main.html');
				}
				else if(s.value == "2"){
					window.open('main-supervisor.php');
				}
				else{
					window.open('main-admin.php');
				}

			}
		</script>
	</div>
	<div>

<center>
	<article style="padding-top: 100px">
	<table style="width:95%;height:600px;background-color:gray;">
		<tr>
			<td class="data">
			<img src="pointer.jpg"><br>
			CHECK AND PAY FOR PINCODE</td>
			<td class="data">INDIVIDUAL APPLICATION FOR PINCODE - INTERNATIONAL GRADUATES</td>
			<td class="data">INDIVIDUAL APPLICATION FOR PINCODE - LOCAL GRADUATES</td>
			<td class="data">
			<img src="pointer.jpg"><br>
			SIGN IN AS PERSONNEL AND CHECK POSTING</td>
		</tr>
		<tr>
			<td class="data">ONLINE REGISTRATION & ENROLLMENT</td>
			<td class="data">
			<img src="pointer.jpg"><br>
			CHECK 2017 POSTING</td>
			<td class="data">VERIFY NSS CERTIFICATE</td>
			<td class="data">REQUEST NSS CERTIFICATE</td>
		</tr>
	</table>
</article>
</center>

		
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>home</title>
<link rel="stylesheet" type="text/css" href="personnelstyle.css">

</head>
<body>




<header class="header1">

<ul style="">

	<li style="display:inline-block;float:left; padding-right:50px;padding-top:15px">
		<img src="NSS-logo.png" style="width:60px;height:40px">
	</li>

	<li style="display:inline-block;float:left;padding-top:20px">
	<form>
		<input type="text" name="search_box" class="search" value="" placeholder="Search NSS Account">
	</form>
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:5px">
		<img src="supervisor.jpg" width="60px" height="60px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="more.jpg" width="20px" height="20px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="question.jpg" width="20px" height="20px">
	</li>

</ul>

</header>

<article style="padding-top:120px">
	
<table style="width: 90%">
	<tr>

		<td style="width:20%">
			<div class="nav_bar">
				<ul class="nav_bar">
					<li class="active">Home</li>
					<a href="Supervisor-View-Form.php"><li class="onhover">Submitted Form</li></a>		
					<a href="workspace.php"><li class="onhover">Workspace</li></a>
					<a href="news.php"><li class="onhover">News</li></a>
				</ul>
				<br><br>
				<center><input type="submit" name="Compose Message" value="Compose Message" class="compose"></center>
			</div>
		</td>


		<td style="width:80%">
			<div style="">
				<center><img src="supervisor.jpg" style="width:100px;height:100px"></center>
			</div>
			<br>
			<div style="font-size:30px;background-color:#1C2833;color: white">
				<center>
					<p>Welcome to Supervisor DashBoard</p>
				</center>
			</div>
		</td>


	</tr>
</table>



</article>


</body>
</html>
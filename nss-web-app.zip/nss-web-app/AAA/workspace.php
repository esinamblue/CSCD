<!DOCTYPE html>
<html>
<head>
	<title>Workspace</title>
<link rel="stylesheet" type="text/css" href="workspace.css">
	<style type="text/css">
		

	</style>
</head>
<body>




<?php include 'header.php'; ?>

<article style="padding-top:120px">
	
<table style="width: 100%" class="space">
	<tr>

		<td style="width:20%">
			<div class="nav_bar">
				<center><input type="submit" name="Compose Message" value="WorkSpace" class="compose"></center><br><br>


<table cellspacing="5px">
	<tr>
		<center><p style="font-weight: bold;font-size:20px;background-color: gray;color: white"> List Submitted Forms</p></center><br>
					
						<th>NSS Numbers</th>
						<th style="text-align: right">Workplace</th>
					</tr>
									<?php

	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

	
	if($dbconnection -> connect_error){
		die("connection failed;". $dbconnection-> connect_error);
	}

	$query = "SELECT * FROM verified_forms WHERE Verified = 'Yes' ";
	$result = $dbconnection->query($query);

	if($result-> num_rows > 0){
		while ($row = $result-> fetch_assoc()) {
			echo "<tr><td>". $row["NSS_Number"] ."</td><td>". $row["Workplace"]. "</td></tr>";
		}
		echo "</table>";
	}
	else{
		echo "0 result";
	}


	$dbconnection->close();

?>
				
				



			</div>


				<br><br>

		</td>


		<td style="width:80%;background-color: #ECF0F1;height: 800px" rowspan="2">
			
			<br>
							<?php

	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

	
	if($dbconnection -> connect_error){
		die("connection failed;". $dbconnection-> connect_error);
	}

	$month = date("F");
	$year = date("Y");

	$query = "SELECT * FROM issueform WHERE Month = date('F') AND Year=$year ";

	if($dbconnection->query($query)==TRUE){
		include 'test2.php';
	}
	else{
		echo "Error: ". $query. "<br>". $dbconnection->error;
	}


	$dbconnection->close();




?>


			</div>
			
				
		</td>


	</tr>
	<tr style="background-color:white; height:50%">
		<td></td>
	</tr>
</table>




</article>



</body>
</html>

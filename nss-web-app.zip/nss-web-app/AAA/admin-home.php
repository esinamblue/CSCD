<!DOCTYPE html>
<html>
<head>
	<title>HOME-ADMINISTRATOR</title>
<link rel="stylesheet" type="text/css" href="personnelstyle.css">

</head>
<body>




<header class="header1">

<ul style="">

	<li style="display:inline-block;float:left; padding-right:50px;padding-top:15px">
		<img src="NSS-logo.png" style="width:60px;height:40px">
	</li>

	<li style="display:inline-block;float:left;padding-top:20px">
	<form>
		<input type="text" name="search_box" class="search" value="" placeholder="Search NSS Account">
	</form>
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:5px">
		<img src="coat.jpg" width="55px" height="70px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="more.jpg" width="20px" height="20px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="question.jpg" width="20px" height="20px">
	</li>

</ul>

</header>

<article style="padding-top:120px">
	
<table style="width: 90%">
	<tr>

		<td style="width:20%">
			<div class="nav_bar">
				<ul class="nav_bar">
					<li class="active">Home</li>
					<a href="admin.php"><li class="onhover">Issue NSS Form</li></a>		
					<a href="Endorse.php"><li class="onhover">View Endorsed Forms</li></a>
					<a href="Operations.php"><li class="onhover">Operations</li></a>
					<a href="supervisor-signup.php"><li class="onhover">Supervisor Acc. SetUp</li></a>
				</ul>
				<br><br>
				<center><input type="submit" name="Compose Message" value="Compose Message" class="compose"></center>
			</div>
		</td>


		<td style="width:80%">
			<div style="">
				<center><img src="arms.jpg" style="width:100px;height:100px"></center>
			</div>
			<br>
			<div style="font-size:30px;background-color:#1C2833;color: white">
				<center>
					<p>Welcome to Administrator DashBoard</p>
				</center>
			</div>
		</td>


	</tr>
</table>



</article>


</body>
</html>
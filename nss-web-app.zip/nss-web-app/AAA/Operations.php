<!DOCTYPE html>
<html>
<head>
	<title>Operations</title>
<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
		.white{
			background-color: white;
		}

		.gray{
			background-color:silver;
		}
	</style>
</head>
<body>




<header class="header1">

<ul style="">

	<li style="display:inline-block;float:left; padding-right:50px;padding-top:15px">
		<img src="NSS-logo.png" style="width:60px;height:40px">
	</li>
	
	<li style="display:inline-block;float:left;padding-top:20px">
	<form>
		<input type="text" name="search_box" class="search" value="" placeholder="Search NSS Account">
	</form>
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:5px">
		<img src="supervisor.jpg" width="60px" height="60px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="more.jpg" width="20px" height="20px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="question.jpg" width="20px" height="20px">
	</li>

</ul>

</header>

<article style="padding-top:120px">
	
<table style="width: 90%" class="space">
	<tr>

		<td style="width:20%">
			<div class="nav_bar">
				<ul class="nav_bar">
					<a href="admin-home.php"><li class="onhover">Home</li></a>
					<a href="admin.php"><li class="onhover">Issue NSS Forms</li></a>
					<a href="Endorse.php"><li class="onhover">View Endorsed Forms</li></a>
					<li class="active">Operations</li>
					<a href="supervisor-signup.php"><li class="onhover">Supervisor Acc. SetUp</li></a>
				</ul>
				<br><br>
				<center><input type="submit" name="Compose Message" value="Compose Message" class="compose"></center>
			</div>
		</td>


		<td style="width:80%;background-color: #ECF0F1;height: 500px;padding-left:30px;padding-right:30px" rowspan="2">
			
			<p style="font-size:20px">OPERATIONS</p><hr><br><br>
			
			<p>List Of Forms Submitted to Supervisors by Date</p><br>
			
			<form method="POST">
				<input type="text" name="date" placeholder="yyyy-mm-dd" required>
				<input type="submit" name="NSS_Date_search" value="Search">
			</form><br>
			<?php
				$connection = mysqli_connect("localhost", "root", "Lmfao007");
				$db = mysqli_select_db($connection, 'nss_account');



				if(isset($_POST['NSS_Date_search'])){
					$date = $_POST['date'];

					$query = "SELECT * FROM Verified_forms WHERE Date_Submitted = '$date'";
					$query_run = mysqli_query($connection,$query);



					while ($row = mysqli_fetch_array($query_run)) 
					{
						
						?>

				<table>
					<tr class="white">
						<td>Workplace</td>
						<td><?php echo $row['Workplace']; ?></td>
					</tr>
					<tr class="gray">
						<td>NSS Number</td>
						<td><?php echo $row['NSS_Number']; ?></td>
					</tr>
					<tr class="white">
						<td>Date Submitted</td>
						<td><?php echo $row['Date_Submitted']; ?></td>
					</tr>
					<tr class="gray">
						<td>Status(Verified)</td>
						<td><?php echo $row['Verified']; ?></td>
					</tr>
				</table><br>


						<?php
					}

				}
			 ?>

			<p>Search NSS Personnel by ID</p><br>
			
			<form method="POST">
				<input type="text" name="NSS_Number" placeholder="NSS Number" required>
				<input type="submit" name="NSS_ID_search" value="Search">
			</form><br>
			<?php
				$connection = mysqli_connect("localhost", "root", "Lmfao007");
				$db = mysqli_select_db($connection, 'nss_account');



				if(isset($_POST['NSS_ID_search'])){
					$NSS_Number = $_POST['NSS_Number'];

					$query = "SELECT * FROM personnel_info WHERE NSS_Number = '$NSS_Number'";
					$query_run = mysqli_query($connection,$query);



					while ($row = mysqli_fetch_array($query_run)) 
					{
						
						?>

				<table>
					<tr class="white">
						<td>Surname</td>
						<td><?php echo $row['surname']; ?></td>
					</tr>
					<tr class="gray">
						<td>Other Name</td>
						<td><?php echo $row['othername']; ?></td>
					</tr>
					<tr class="white">
						<td>NSS_Number</td>
						<td><?php echo $row['NSS_Number']; ?></td>
					</tr>
					<tr class="gray">
						<td>Date Of Birth</td>
						<td><?php echo $row['dob']; ?></td>
					</tr>
					<tr class="white">
						<td>Email</td>
						<td><?php echo $row['email']; ?></td>
					</tr>
					<tr class="gray">
						<td>Phone</td>
						<td><?php echo $row['phone']; ?></td>
					</tr>
					<tr class="white">
						<td>Institution</td>
						<td><?php echo $row['institution']; ?></td>
					</tr>
					<tr class="gray">
						<td>Index Number</td>
						<td><?php echo $row['std_id']; ?></td>
					</tr>
					<tr class="white">
						<td>Workplace</td>
						<td><?php echo $row['workplace']; ?></td>
					</tr>
					<tr class="gray">
						<td>District</td>
						<td><?php echo $row['district']; ?></td>
					</tr>
					<tr class="white">
						<td>Region</td>
						<td><?php echo $row['region']; ?></td>
					</tr>
					<tr class="gray">
						<td>Ezwich Number</td>
						<td><?php echo $row['enumber']; ?></td>
					</tr>
				</table><br>


						<?php
					}

				}
			 ?>
			<br><br>
			


			<p>Search NSS Personnel by Workplace</p>
			<form method="POST">
				<input type="text" name="workplace" placeholder="Workplace" required>
				<input type="submit" name="NSS_Workplace_search" value="Search">
			</form>
			<br>
			<?php
				$connection = mysqli_connect("localhost", "root", "Lmfao007");
				$db = mysqli_select_db($connection, 'nss_account');



				if(isset($_POST['NSS_Workplace_search'])){
					$Workplace = $_POST['workplace'];

					$query = "SELECT * FROM personnel_info WHERE Workplace = '$Workplace'";
					$query_run = mysqli_query($connection,$query);



					while ($row = mysqli_fetch_array($query_run)) 
					{
						
						?>

				<table>
					<tr class="white">
						<td>Surname</td>
						<td><?php echo $row['surname']; ?></td>
					</tr>
					<tr class="gray">
						<td>Other Name</td>
						<td><?php echo $row['othername']; ?></td>
					</tr>
					<tr class="white">
						<td>NSS_Number</td>
						<td><?php echo $row['NSS_Number']; ?></td>
					</tr>
					<tr class="gray">
						<td>Date Of Birth</td>
						<td><?php echo $row['dob']; ?></td>
					</tr>
					<tr class="white">
						<td>Email</td>
						<td><?php echo $row['email']; ?></td>
					</tr>
					<tr class="gray">
						<td>Phone</td>
						<td><?php echo $row['phone']; ?></td>
					</tr>
					<tr class="white">
						<td>Institution</td>
						<td><?php echo $row['institution']; ?></td>
					</tr>
					<tr class="gray">
						<td>Index Number</td>
						<td><?php echo $row['std_id']; ?></td>
					</tr>
					<tr class="white">
						<td>Workplace</td>
						<td><?php echo $row['workplace']; ?></td>
					</tr>
					<tr class="gray">
						<td>District</td>
						<td><?php echo $row['district']; ?></td>
					</tr>
					<tr class="white">
						<td>Region</td>
						<td><?php echo $row['region']; ?></td>
					</tr>
					<tr class="gray">
						<td>Ezwich Number</td>
						<td><?php echo $row['enumber']; ?></td>
					</tr>
				</table><br>
					

						<?php
					}

				}
			 ?>
			<br><br>


			<p>Remove NSS Personnel Account by ID</p>
			<form method="POST">
				<input type="text" name="NSS_Number" placeholder="NSS Number" required>
				<input type="submit" name="NSS_ID_remove" value="Remove">
			</form>
			<br><br><br>
			<?php

			$connection = mysqli_connect("localhost", "root", "Lmfao007");
			$db = mysqli_select_db($connection, 'nss_account');

			if(isset($_POST['NSS_ID_remove'])){
					$NSS_Number = $_POST['NSS_Number'];

					$query = "DELETE FROM personnel_info WHERE NSS_Number = '$NSS_Number'";
					$query_run = mysqli_query($connection,$query);

					if($dbconnection->query($query)==TRUE){
		echo "NSS Personnel Account Removed Successfully";
	}
	else{
		echo "Error: ". $query. "<br>". $dbconnection->error;
	}


	$dbconnection->close();

				}
			?>
			
			<br>

			<p>List of Endorsed Forms by Date</p><br>
			
			<form method="POST">
				<input type="text" name="date"  placeholder="yyyy-mm-dd" required>
				<input type="submit" name="Supverv_Date_search" value="Search">
			</form><br>
			<?php
				$connection = mysqli_connect("localhost", "root", "Lmfao007");
				$db = mysqli_select_db($connection, 'nss_account');



				if(isset($_POST['Supverv_Date_search'])){
					$date = $_POST['date'];

					$query = "SELECT * FROM Endorsed_forms WHERE Date_Endorsed = '$date'";
					$query_run = mysqli_query($connection,$query);



					while ($row = mysqli_fetch_array($query_run)) 
					{
						
						?>

				<table>
					<tr class="white">
						<td>Workplace</td>
						<td><?php echo $row['Workplace']; ?></td>
					</tr>
					<tr class="gray">
						<td>NSS Number</td>
						<td><?php echo $row['NSS_Number']; ?></td>
					</tr>
					<tr class="white">
						<td>Date Submitted</td>
						<td><?php echo $row['Date_Endorsed']; ?></td>
					</tr>
					<tr class="gray">
						<td>Supervisor Signature Image</td>
						<td><?php echo $row['Signature_img']; ?></td>
					</tr>
				</table><br>


						<?php
					}

				}
			 ?>
			

			<p>Search Supervisor by Workplace</p>
			<form method="POST">
				<input type="text" name="Workplace" placeholder="Superv. Workplace" required>
				<input type="submit" name="Superv_Workplace_search" value="Search">
			</form>
			<br>

			<?php
				$connection = mysqli_connect("localhost", "root", "Lmfao007");
				$db = mysqli_select_db($connection, 'nss_account');



				if(isset($_POST['Superv_Workplace_search'])){
					$Workplace = $_POST['Workplace'];

					$query = "SELECT * FROM supervisor_info WHERE Workplace = '$Workplace'";
					$query_run = mysqli_query($connection,$query);



					while ($row = mysqli_fetch_array($query_run)) 
					{
						
						?>

				<table>
					<tr class="white">
						<td>Full Name</td>
						<td><?php echo $row['fullname']; ?></td>
					</tr>
					<tr class="gray">
						<td>Date Of Birth</td>
						<td><?php echo $row['dob']; ?></td>
					</tr>
					<tr class="white">
						<td>Email</td>
						<td><?php echo $row['s_email']; ?></td>
					</tr>
					<tr class="gray">
						<td>Phone Number</td>
						<td><?php echo $row['s_phone']; ?></td>
					</tr>
					<tr class="white">
						<td>Workplace</td>
						<td><?php echo $row['workplace']; ?></td>
					</tr>
					<tr class="gray">
						<td>Organization Email</td>
						<td><?php echo $row['w_email']; ?></td>
					</tr>
					<tr class="white">
						<td>Organization Phone</td>
						<td><?php echo $row['w_phone']; ?></td>
					</tr>
					<tr class="gray">
						<td>Digital Address</td>
						<td><?php echo $row['dig_address']; ?></td>
					</tr>
					<tr class="white">
						<td>District</td>
						<td><?php echo $row['district']; ?></td>
					</tr>
					<tr class="gray">
						<td>Region</td>
						<td><?php echo $row['region']; ?></td>
					</tr>
				</table><br>
					

						<?php
					}

				}
			 ?>
			<br><br>



			<p>Remove Supervisor Account by ID/Workplace</p>
			<form method="POST">
				<input type="text" name="Superv_ID" placeholder="Superv. ID"><br><br>
				<input type="text" name="Workplace" placeholder="Superv. Workplace">
				<input type="submit" name="Superv_Workplace_remove" value="Remove">
			</form>
			<br>
			<?php

			$connection = mysqli_connect("localhost", "root", "Lmfao007");
			$db = mysqli_select_db($connection, 'nss_account');

			if(isset($_POST['Superv_Workplace_remove'])){
					$Superv_ID = $_POST['Superv_ID'];

					$query = "DELETE FROM supervisor_info WHERE Superv_ID = '$Superv_ID'";
					$query_run = mysqli_query($connection,$query);

					if($dbconnection->query($query)==TRUE){
		echo "Supervisor Account Removed Successfully";
	}
	else{
		echo "Error: ". $query. "<br>". $dbconnection->error;
	}


	$dbconnection->close();

				}
			?>
			<?php

			$connection = mysqli_connect("localhost", "root", "Lmfao007");
			$db = mysqli_select_db($connection, 'nss_account');

			if(isset($_POST['Superv_Workplace_remove'])){
					$Workplace = $_POST['Workplace'];

				$query = "DELETE FROM supervisor_info WHERE Workplace = '$Workplace'";
					$query_run = mysqli_query($connection,$query);
				if($dbconnection->query($query)==TRUE){
		echo "Supervisor Account Removed Successfully";
	}
	else{
		echo "Error: ". $query. "<br>". $dbconnection->error;
	}


	$dbconnection->close();

				}
			?>
		
	
		</td>
		

	</tr>
	<tr style="background-color:white; height:50%">
		<td></td>
	</tr>
</table>




</article>



</body>
</html>

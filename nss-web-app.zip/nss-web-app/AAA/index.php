<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="personnelstyle.css">
<style type="text/css">
		button {
		background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:80px;
			height:30px;
			cursor: pointer;
	}

	#Select {
		border-style: 2em;
		border-color:#900C3F;
		width: 200px;
		height:30px;
		border-radius: 10px;
	}

	.data{
		background-color:white;
		width:50px;
		height: 150px;
		text-align: center;
	}

	table{
		border-spacing:40px;
		font-weight: bold;
		color: green;
	}

	footer{
		position: fixed;
		background-color: #1C2833;
		color: white;
		bottom:0;
		width:100%;
	}

	.data img{
		width:120px;
		height:120px;
	}
</style>	
</head>
<body>
	<header class="header1">

<ul style="">

	<li style="display:inline-block;float:left; padding-right:50px;padding-top:15px">
		<img src="NSS-logo.png" style="width:60px;height:40px">
	</li>



	<li style="display:inline-block;float:right; padding-right:10%;padding-top:25px">
		<select id="Select" name="Select">
					<option value="1">NSS Personnel</option>
					<option value="2">Supervisor</option>
					<option value="3">Administrator</option>
			</select>
			<button onclick="Display()">Login</button>
	</li>


</ul>

</header>
	<div>
		
			

		<script type="text/javascript">

			function Display(){
			var s = document.getElementById('Select');

				if(s.value == "1"){
				window.open('new-main.php');
				}
				else if(s.value == "2"){
					window.open('main-supervisor.php');
				}
				else{
					window.open('main-admin.php');
				}

			}
		</script>
	</div>
	<div>

<center>
	<article style="padding-top: 100px">
	<table style="width:95%;height:600px;background-color: #ECF0F1;">
		<tr>
			<td class="data">
			<img src="pointer.jpg"><br>
			CHECK AND PAY FOR PINCODE</td>
			<td class="data">
			<img src="globe.jpg" style="width:90px;height:93px"><br>
			INDIVIDUAL APPLICATION FOR PINCODE - INTERNATIONAL GRADUATES</td>
			<td class="data">
			<img src="gh.jpg"><br>
			INDIVIDUAL APPLICATION FOR PINCODE - LOCAL GRADUATES</td>
			<td class="data">
			<img src="pointer.jpg"><br>
			SIGN IN AS PERSONNEL AND CHECK POSTING</td>
		</tr>
		<tr>
			<td class="data">
			<img src="form.png"><br>
			ONLINE REGISTRATION & ENROLLMENT</td>
			<td class="data">
			<img src="pointer.jpg"><br>
			CHECK 2017 POSTING</td>
			<td class="data">
			<img src="correct.jpg"><br>
			VERIFY NSS CERTIFICATE</td>
			<td class="data">
			<img src="cert.png" style="width:170px"><br>
			REQUEST NSS CERTIFICATE</td>
		</tr>
	</table>
</article>
</center>
<footer style="padding-bottom: 15px">

<ul>

	<li style="display:inline-block;float:right; padding-right:10%;padding-top:15px">
		<button onclick="window.open('signup.php')">SignUp</button>

	</li>
	<li style="display:inline-block;float:right; padding-right:10px;padding-top:15px"> 
		<p>Sign Up As NSS Personnel</p> 
	</li>


</ul>

</footer>
		
</body>
</html>
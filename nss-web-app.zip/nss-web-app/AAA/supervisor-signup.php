
<!DOCTYPE html>
<html>
<head>
	<title>SET UP SUPERVISOR ACCOUNT</title>
	<style type="text/css">
		*{
			margin: 0;
		}


		.panel{
			height:820px;
			width :35%;
			background-color: white;
			padding-top: 5%;
			border-radius: 10px;
			background-color: #BACBE1;
		}

		.personnel_info{
			padding-top:5%;
		}

		input{
			width:50%;
			height:20px;
			border-radius:5px;
			border-style: none;
			padding-left:10px;
		}

		input[type=submit]{
			background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:50%;
			height:30px;
			cursor: pointer;
			opacity:0.8;
		}

		input[type=submit]:hover{
			opacity:1;
		}

		input[type=reset]{
			background-color: #7E7C79;
			color:white;
			border-radius: 20px;
			width:50%;
			height:30px;
			border-style: none;
			cursor: pointer;
			opacity:0.6;
		}

		input[type=reset]:hover{
			opacity:1;
		}

		header{
			background-color: white;
			height: 10%;
			width:100%;
			position:fixed;
			display:inline-block;
			box-shadow: 0 2px 20px grey;
		}

	</style>
</head>
<body>
	<header>
		<ul>
		<li style="display:inline-block;float:left; padding-right:50px;padding-top:10px">
			<img src="NSS-logo.png" style="width:60px; height:40px;">
		</li>
		<li style="display:inline-block;padding-top:20px;padding-left:32%;">
			<center><strong>SET UP SUPERVISOR ACCOUNT</strong></center>
		</li>
		<li style="display:inline-block;padding-top:20px;float:right; padding-right:10px">
			<a href="main-supervisor.php">Already have account? Sign In</a>
		</li>

		</ul>

		<script type="text/javascript">

			function Validate() {
				var password = document.getElementById("pwd").value;
				var confirm = document.getElementById("co_pwd").value;

				if (password != confirm) {
					alert("Passwords do not match");
					window.history.back('supervisor-signup.php');

					return false;
				}
			}

	</script>


	</header>
<center>

	
	<br><br><br><br><br><br><br><br>
	<article class="panel" >
		
		<form method="POST" action="operations.php" name="form1" class="personnel_info">
			<p>Account Details</p>
			<input type="text" name="fullname" placeholder="Fullname" required><br><br>
			<input type="date" name="dob" placeholder="Date Of Birth" required><br><br>
			<input type="email" name="s_email" placeholder="Superv. Email" required><br><br>
			<input type="text" name="s_phone" placeholder="Superv. Phone Number" required><br><br>
			<p>Organization Details</p>
			<input type="text" name="workplace" placeholder="Industry/Place Of Work" required><br><br>
			<input type="email" name="w_email" placeholder="Org. Email" required><br><br>
			<input type="text" name="w_phone" placeholder="Org. Phone Number" required><br><br>
			<input type="text" name="dig_address" placeholder="Digital Address" required><br><br>
			<input type="text" name="district" placeholder="District" required><br><br>
			<input type="text" name="region" placeholder="Region" required><br><br>
				<br><br>
			<input type="password" name="password" id="pwd" placeholder="Password" required><br><br>
			<input type="password" name="confirm" id="co_pwd" placeholder="Confirm Password" required><br><br>
			<input type="submit" onclick="Validate()" name="submit" value="submit" id="submit" ><br><br>
			<input type="reset" name="reset">
		</form>

		<?php


	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

if(isset($_POST['submit'])){
	$fullname = $_POST['fullname'];
	$dob = $_POST['dob'];
	$s_email = $_POST['s_email'];
	$s_phone = $_POST['s_phone'];
	$workplace = $_POST['workplace'];
	$w_email = $_POST['w_email'];
	$w_phone = $_POST['w_phone'];
	$dig_address = $_POST['dig_address'];
	$district = $_POST['district'];
	$region = $_POST['region'];
	$password = $_POST['password'];

	
	if($dbconnection -> connect_error){
		die("connection failed;". $dbconnection-> connect_error);
	}

	$query = "INSERT INTO supervisor_info(fullname,dob,s_email,s_phone,workplace,w_email,w_phone,dig_address,district,region,password) VALUES ('$fullname','$dob','$s_email','$s_phone','$workplace','$w_email','$w_phone','$dig_address','$district','$region','$password')";

	if($dbconnection->query($query)==TRUE){
		echo "Worked";
	}
	else{
		echo "Error: ". $query. "<br>". $dbconnection->error;
	}
}


	$dbconnection->close();

	?>
	


		


	</article>

</center>

</body>



</html>
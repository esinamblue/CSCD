<!DOCTYPE html>
<html>
<head>
	<title>LIST OF ENDORSED FORMS</title>
<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">

	</style>
</head>
<body>




<header class="header1">

<ul style="">

	<li style="display:inline-block;float:left; padding-right:50px;padding-top:15px">
		<img src="NSS-logo.png" style="width:60px;height:40px">
	</li>
	
	<li style="display:inline-block;float:left;padding-top:20px">
	<form>
		<input type="text" name="search_box" class="search" value="" placeholder="Search NSS Account">
	</form>
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:5px">
		<img src="supervisor.jpg" width="60px" height="60px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="more.jpg" width="20px" height="20px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="question.jpg" width="20px" height="20px">
	</li>

</ul>

</header>

<article style="padding-top:120px">
	
<table style="width: 95%" class="space">
	<tr>

		<td style="width:20%">
			<div class="nav_bar">
				<ul class="nav_bar">
					<a href="admin-home.php"><li class="onhover">Home</li></a>
					<a href="admin.php"><li class="onhover">Issue NSS Forms</li></a>
					<li class="active">View Endorsed Forms</li>
					<a href="Operations.php"><li class="onhover">Operations</li></a>
					<a href="supervisor-signup.php"><li class="onhover">Supervisor Acc. SetUp</li></a>
				</ul>
				<br><br>
				<center><input type="submit" name="Compose Message" value="Compose Message" class="compose"></center>
			</div>
		</td>


		<td style="width:80%;background-color: #ECF0F1;height: 500px" rowspan="2">
			
			<br>
			<div class="top">
				<p style="font-size: 20px;font-weight: bold">LIST OF ENSORSED FORMS</p><br><br>
				<table cellspacing="10px">
					<tr>
						<th>Supervisor ID</th>
						<th>Workplace</th>
						<th>NSS Personnel Number</th>
						<th>Date Submitted</th>
						<th>Supervisor Sign. Image</th>
					</tr>
									<?php

	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

	
	if($dbconnection -> connect_error){
		die("connection failed;". $dbconnection-> connect_error);
	}

	$query = "SELECT * FROM endorsed_forms";
	$result = $dbconnection->query($query);

	if($result-> num_rows > 0){
		while ($row = $result-> fetch_assoc()) {
			echo "<tr><td>". $row["Supervisor_ID"] ."</td><td>". $row["Workplace"] ."</td><td>". $row["NSS_Number"]."</td><td>". $row["Date_Endorsed"]."</td><td>". $row["Signature_img"]. "</td></tr><br>";
		}
		echo "</table>";
	}
	else{
		echo "0 result";
	}


	$dbconnection->close();

?>
				
				



			</div>
		</td>


	</tr>
	<tr style="background-color:white; height:50%">
		<td></td>
	</tr>
</table>




</article>



</body>
</html>

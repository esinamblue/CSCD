<?php

	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

	
	$month = $_POST['month'];
	$year = $_POST['year'];
	$deadline = $_POST['deadline'];

	

	//$result = mysql_query($query);
	
	if($dbconnection -> connect_error){
		die("connection failed;". $dbconnection-> connect_error);
	}

	$query = "INSERT INTO issueform(Month,Year,deadline) VALUES ('$month','$year','$deadline')";

	if($dbconnection->query($query)==TRUE){
		
	}
	else{
		echo "Error: ". $query. "<br>". $dbconnection->error;
	}


	$dbconnection->close();




?>
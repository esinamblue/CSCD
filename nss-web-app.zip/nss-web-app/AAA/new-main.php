<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!--<script type="text/javascript" src="new-main.js"></script>-->


	<style type="text/css">
		

*{
	margin: 0;
	font-family: arial;
}

body{
	background-image: linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),url(bg1.jpg);
	background-position: center;
	background-size: cover;
	background-color:#4CAF50;
	height: 100%;	
}

.loginBox input[type=text] {
  width:65%;
  border-radius: 10px;
  background-color: silver;
  display: block;
  height:40px;
  border:none;
  border-radius:40px;
  font-size: 15px;
  font-family: arial;
  padding-left:20px;
} 


.loginBox input[type=password] {

  width:65%;
  border-radius: 10px;
  background-color: silver;
  display: block;
  height:40px;
  border:none;
  border-radius:40px;
  padding-left:20px;
  font-size: 15px;
  font-family: arial;

} 

input[type=radio]{
	/*float:left;
	margin-left:54px;*/
}

.loginBox button{
			background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:70%;
			height:40px;
			cursor: pointer;
			opacity:0.8;
}

button:hover{
	opacity:1;
} 



.loginBox{
	background-color: white;
	width:35%;
	height:600px;
	padding-top:5%;
	border-radius: 10px;
}

.Ash{
	background-color: silver;
	width:360px;
	height:60px;
	border-radius:10px;
	border:none;
}

i{
	background-color:silver;
	padding-top:19px;
	padding-right:15px;
}

	</style>
</head>
<body>
	<br><br>
	<center>
	<div class="loginBox">
		<img src="NSS-logo.png" id="img" style="height: 12%;width: 25%">
		<br><br><br>
			<p style="font-size:25px">Sign In As NSS Personnel</p><br><br><br><br><br>
			<form action="" method="POST" >
				<p>NSS Number:</p>
				<input type="text" name="NSS_Number" placeholder="NSSGUGXXXXXXX" required><br><br>
				<p>Password:</p>
				<input type="password" name="password" placeholder="Password" required>
				<br>
				<br><br><br><br>

				<button type="submit" name="submit" class="button">Sign In</button>
			</form>

			<br>
			<a href="signup.php">Don't Have Account? Sign Up</a>

	</div>


	</center>

	<?php

	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);
   
   if(isset($_POST['submit'])) {
      
      $NSS_Number = $_POST['NSS_Number'];
      $password = $_POST['password']; 
      
      $sql = "SELECT * FROM personnel_info WHERE NSS_Number = '$NSS_Number' and Password = '$password'";
      $result = mysqli_query($dbconnection,$sql);

      while ($row = mysqli_fetch_array($result)) 
					{
      $number = $row['NSS_Number'];
      $pwd = $row['password'];
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($NSS_Number==$number && $password==$pwd) {
      		header("Location: home.html");
      }
      else {
         echo "Your Login Name or Password is invalid";
      }

   }
}
?>
</body>
</html>
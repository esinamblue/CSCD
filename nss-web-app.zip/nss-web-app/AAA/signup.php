<!DOCTYPE html>
<html>
<head>
	<title>Sign Up As NSS Personnel</title>
	<style type="text/css">
		*{
			margin: 0;
		}


		.panel{
			height:820px;
			width :35%;
			background-color: white;
			padding-top: 5%;
			border-radius: 10px;
			background-color: #BACBE1;
		}

		.personnel_info{
			padding-top:5%;
		}

		input{
			width:50%;
			height:20px;
			border-radius:5px;
			border-style: none;
			padding-left:10px;
		}

		input[type=submit]{
			background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:50%;
			height:30px;
			cursor: pointer;
			opacity:0.8;
		}

		input[type=submit]:hover{
			opacity:1;
		}

		input[type=reset]{
			background-color: #7E7C79;
			color:white;
			border-radius: 20px;
			width:50%;
			height:30px;
			border-style: none;
			cursor: pointer;
			opacity:0.6;
		}

		input[type=reset]:hover{
			opacity:1;
		}

		header{
			background-color: white;
			height: 10%;
			width:100%;
			position:fixed;
			display:inline-block;
			box-shadow: 0 2px 20px grey;
		}

	</style>
</head>
<body>
	<header>
		<ul>
		<li style="display:inline-block;float:left; padding-right:50px;padding-top:10px">
			<img src="NSS-logo.png" style="width:60px; height:40px;">
		</li>
		<li style="display:inline-block;padding-top:20px;padding-left:32%;">
			<center><strong>Sign Up As NSS Personnel</strong></center>
		</li>
		<li style="display:inline-block;padding-top:20px;float:right; padding-right:10px">
			<a href="new-main.php">Already have account? Sign In</a>
		</li>

		</ul>

		<script type="text/javascript">

			function Validate() {
				var password = document.getElementById("pwd").value;
				var confirm = document.getElementById("co_pwd").value;

				if (password != confirm) {
					alert("Passwords do not match");
					window.history.back('signup.php');

					return false;
				}
			}

	</script>


	</header>
<center>

	
	<br><br><br><br><br><br><br><br>
	<article class="panel" >
		
		<form method="POST" action="insert.php" name="form1" class="personnel_info">
			<p>Account Details</p>
			<input type="text" name="surname" placeholder="Surname" required><br><br>
			<input type="text" name="othername" placeholder="Other Name" required><br><br>
			<input type="text" name="NSS_Number" placeholder="NSSGUGXXXXXXX" required><br><br>
			<input type="date" name="dob" placeholder="Date Of Birth" required><br><br>
			<input type="email" name="email" placeholder="Email" required><br><br>
			<input type="text" name="phone" placeholder="Phone Number" required><br><br>
			<input type="password" name="password" id="pwd" placeholder="Password" required><br><br>
			<input type="password" name="confirm" id="co_pwd" placeholder="Confirm Password" required><br><br>
			<p>Previous Educational Institution</p>
			<input type="text" name="institution" placeholder="Institution Name" required><br><br>
			<input type="text" name="std_id" placeholder="Student ID" required><br><br>
			<p>Current NSS Workplace</p>
			<input type="text" name="workplace" placeholder="Industry/Place Of Work" required><br><br>
			<input type="text" name="enumber" placeholder="Ezwich Number" required><br><br>
			<input type="text" name="district" placeholder="District" required><br><br>
			<input type="text" name="region" placeholder="Region" required><br><br>
				<br><br>
			<input type="submit" onclick="Validate()" name="submit" value="submit" id="submit" ><br><br>
			<input type="reset" name="reset">
		</form>


		


	</article>

</center>

</body>



</html>
 <?php 
 		/*$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

		if(isset($_POST['search'])){
					$NSS_Number = $_POST['NSS_Number'];

					$query = "SELECT * FROM personnel_info WHERE NSS_Number = '$NSS_Number'";
					$query_run = mysqli_query($connection,$query);



					while ($row = mysqli_fetch_array($query_run)) 
					{
						
						?>

						<table>
					<tr class="white">
						<td>Workplace</td>
						<td><?php
						$connection = mysqli_connect("localhost", "root", "Lmfao007");
						$db = mysqli_select_db($connection, 'nss_account');

						 echo $workplace = $row['workplace']; 
						 $query2 = "INSERT INTO endorsed_forms(Workplace) AND ('$workplace')";
						$query_run2 = mysqli_query($connection,$query2);
						 ?></td>
					</tr>
					</table>

						<?php
					}

				}
			 ?>

  <?php 



 /*		$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

 if (isset($_POST['upload'])) {	
	if($dbconnection -> connect_error){
		die("connection failed;". $dbconnection-> connect_error);
	}


 	$NSS_Number = $_POST['image_text'];

    $query = "INSERT INTO endorsed_forms(Workplace) VALUES ('$workplace')";
    $query_run = mysqli_query($dbconnection,$query);

}
    $dbconnection -> close();*/
 ?>
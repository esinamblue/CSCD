
<!--second-->

<!DOCTYPE html>
<html>
<head>
	<title>Issue Form</title>
	<style type="text/css">
			*{
			margin:0px;
			font-family: Arial;
		}

		header.header1{
		width:100%;
		position: fixed;
		top: 0px;
		height: 75px;
		text-align: center;
		display: block;
		box-shadow: 0 2px 20px grey;
	}

	.header1{
		
	}


	.search{
		line-height:25px;
		width:700px;
		border-radius: 15px;
		border-style: none;
		padding-left:35px;
		box-shadow: 0 1px 5px grey;
		background-image: url('search.jpg');
		position: left;
		background-size:30px;
		background-repeat: no-repeat;
	}

	div.nav_bar{
		float: left;
		position:relative;
	}

	ul li{
		list-style:none;
		line-height: 30px;
		display:block;
	}

	.nav_bar{
		line-height:30px;
		width:100%;
	}

	.active{
		margin:auto;
		background-color: #900C3F;
		color:white;
		border-top-right-radius:20px;
		border-bottom-right-radius:20px;
		padding-left:20px;
	}

	.onhover{
		padding-left:20px;
	}

	.onhover:hover{
		margin:auto;
		background-color:#7E7C79;
		color:white;
		border-top-right-radius:20px;
		border-bottom-right-radius:20px;
	}

	.compose{
		background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:80%;
			height:40px;
			cursor: pointer;
			opacity:0.8;
	}

	.compose:hover{
		opacity: 1;
	}

	a{
		text-decoration: none;
		color:black;
	}

	.space{
		border-spacing: 50px;
	}

	.top{
		position: absolute;
		top:35%;
		padding-left: 20px;
	}

	.issueform input[type=text]{
			width: 50%;
		}
	.issueform input[type=date]{
			width: 50%;
		}
	.issueform input[type=submit]{
			width: 50%;
			height:30px;
			border-radius:20px;
			color:#900C3F;
			border: solid #900C3F 2px;
		}




	</style>
</head>
<body>




<header class="header1">

<ul style="">

	<li style="display:inline-block;float:left; padding-right:50px;padding-top:15px">
		<img src="NSS-logo.png" style="width:60px;height:40px">
	</li>

	<li style="display:inline-block;float:left;padding-top:20px">
	<form>
		<input type="text" name="search_box" class="search" value="" placeholder="Search NSS Account">
	</form>
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:5px">
		<img src="coat.jpg" width="50px" height="67px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="more.jpg" width="20px" height="20px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="question.jpg" width="20px" height="20px">
	</li>

</ul>

</header>

<article style="padding-top:120px">
	
<table style="width: 90%" class="space">
	<tr>

		<td style="width:20%">
			<div class="nav_bar">
				<ul class="nav_bar">
					<a href="admin-home.php"><li class="onhover">Home</li></a>
					<li class="active">Issue NSS Form</li>
					<a href="Endorse.php"><li class="onhover">View Endorsed Forms</li></a>
					<a href="operations.php"><li class="onhover">Operations</li></a>
					<a href="supervisor-signup.php"><li class="onhover">Supervisor Acc. SetUp</li></a>
				</ul>
				<br><br>
				<center><input type="submit" name="Compose Message" value="Compose Message" class="compose"></center>
			</div>
		</td>


		<td style="width:80%;background-color: #ECF0F1;height: 500px" rowspan="2">
			<center>
				<p style="font-size:20px">Issue Forms</p><br><br>

		<form method="POST" action="admin.php" class="issueform">
		<input type="text" name="month" placeholder="month" required><br><br><br>
		<input type="text" name="year" placeholder="year" required><br><br><br>
		<input type="date" name="deadline" placeholder="set deadline" required><br><br><br>
		<input type="checkbox" name="yes" value="yes" onchange="document.getElementById('btSubmit').disabled = !this.checked" required> Are You Sure You Want to Issue The Information Provided? YES.
				<br><br><br>
		<input type="submit" id="btSubmit" value="Issue Form" disabled>


	</form></center>
			<br>
			<div style="font-size:20px">
				
			</div>
		</td>


	</tr>
	<tr>
		<td style="background-color: white;height:50%"></td>
	</tr>
</table>


<?php include 'issue.php'; ?>	



</article>



</body>
</html>
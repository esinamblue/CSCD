<!DOCTYPE html>
<html>
<head>
	<title>home</title>

	<style type="text/css">
				*{
			margin:0px;
			font-family: Arial;
		}

		header.header1{
		width:100%;
		position: fixed;
		top: 0px;
		height: 75px;
		text-align: center;
		display: block;
		box-shadow: 0 2px 20px grey;
		background-color: white;
	}

	.header1{
		
	}

	div.nav_bar{
		float: left;
		position:relative;
	}

	ul li{
		list-style:none;
		line-height: 30px;
		display:block;
	}

	.nav_bar{
		line-height:30px;
		width:100%;
	}

	.active{
		margin:auto;
		background-color: #900C3F;
		color:white;
		border-top-right-radius:20px;
		border-bottom-right-radius:20px;
		padding-left:20px;
	}

	.onhover{
		padding-left:20px;
	}

	.onhover:hover{
		margin:auto;
		background-color:#7E7C79;
		color:white;
		border-top-right-radius:20px;
		border-bottom-right-radius:20px;
	}

	.compose{
		background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:80%;
			height:40px;
			cursor: pointer;
			opacity:0.8;
	}

	.compose:hover{
		opacity: 1;
	}

	a{
		text-decoration: none;
		color:black;
	}

	.space{
		border-spacing: 50px;
	}

	.search{
		line-height:25px;
		width:700px;
		border-radius: 15px;
		border-style: none;
		padding-left:35px;
		box-shadow: 0 1px 5px grey;
		background-image: url('search.jpg');
		position: left;
		background-size:30px;
		background-repeat: no-repeat;
	}

	.new{
		width:200px;
	}

	.top{
		position: absolute;
		top:35%;
		padding-left: 20px;
	}

	</style>
</head>
<body>




<header class="header1">

<ul style="">

	<li style="display:inline-block;float:left; padding-right:50px;padding-top:15px">
		<img src="NSS-logo.png" style="width:60px;height:40px">
	</li>
	
	<li style="display:inline-block;float:left;padding-top:20px">
	<form>
		<input type="text" name="search_box" class="search" value="" placeholder="Search NSS Account">
	</form>
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:5px">
		<img src="supervisor.jpg" width="60px" height="60px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="more.jpg" width="20px" height="20px">
	</li>

	<li style="display:inline-block;float:right; padding-right:30px;padding-top:25px">
		<img src="question.jpg" width="20px" height="20px">
	</li>

</ul>

</header>

<article style="padding-top:120px">
	
<table style="width: 90%" class="space">
	<tr>

		<td style="width:20%">
			<div class="nav_bar">
				<ul class="nav_bar">
					<a href="supervisor-home.php"><li class="onhover">Home</li></a>
					<li class="active">Submitted Forms</li>
					<a href="Workspace.php"><li class="onhover">Workspace</li></a>
					<a href="news.php"><li class="onhover">News</li></a>
				</ul>
				<br><br>
				<center><input type="submit" name="Compose Message" value="Compose Message" class="compose"></center>
			</div>
		</td>


		<td style="width:80%;background-color: #ECF0F1;height: 500px" rowspan="2">
			
			<br>
			<div class="top">
				<p style="font-size: 20px;font-weight: bold">LIST OF SUBMITTED FORMS</p><br><br>
				<table cellspacing="10px">
					<tr>
						<th>Workplace</th>
						<th>NSS Personnel Number</th>
						<th>Date Submitted</th>
						<th>Verified By Personnel</th>
					</tr>
									<?php

	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

	
	if($dbconnection -> connect_error){
		die("connection failed;". $dbconnection-> connect_error);
	}

	$query = "SELECT * FROM verified_forms WHERE Verified = 'Yes' ";
	$result = $dbconnection->query($query);

	if($result-> num_rows > 0){
		while ($row = $result-> fetch_assoc()) {
			echo "<tr><td>". $row["Workplace"] ."</td><td>". $row["NSS_Number"] ."</td><td>". $row["Date_Submitted"] ."</td><td>". $row["Verified"]. "</td></tr>";
		}
		echo "</table>";
	}
	else{
		echo "0 result";
	}


	$dbconnection->close();

?>
				
				



			</div>
		</td>


	</tr>
	<tr style="background-color:white; height:50%">
		<td></td>
	</tr>
</table>




</article>



</body>
</html>

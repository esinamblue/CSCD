

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		*{
			font-family: arial;
			font-size: 25px;
		}

		.login{
			border-radius: 20px;
			width:50%;
			height:50px;
		}

		.yes{
			background-color: #900C3F;
			box-shadow: 0 1px 5px grey;
			color:white;
			border-style: none;
			border-radius: 20px;
			width:40%;
			height:30px;
			cursor: pointer;
			opacity:0.8;
		}

		.yes:hover{
			opacity:1;
		}

		.no{
			background-color: #7E7C79;
			color:white;
			border-radius: 20px;
			width:20%;
			height:30px;
			border-style: none;
			cursor: pointer;
			opacity:0.6;
		}

		.no:hover{
			opacity:1;
		}


	</style>
</head>
<body>
	<center>


	<?php

	$dbhost = 'localhost';
	$username = 'root';
	$password = 'Lmfao007';
	$dbname = 'nss_account';
	$dbconnection = new mysqli($dbhost,$username,$password,$dbname);

 	$surname = $_POST['surname'];
	$othername = $_POST['othername'];
	$dob = $_POST['dob'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$password = $_POST['password'];
	$institution = $_POST['institution'];
	$std_id = $_POST['std_id'];
	$workplace = $_POST['workplace'];
	$enumber = $_POST['enumber'];
	$district = $_POST['district'];
	$region = $_POST['region'];
	$NSS_Number = $_POST['NSS_Number'];

	

	//$result = mysql_query($query);
	
	if($dbconnection -> connect_error){
		die("connection failed;". $dbconnection-> connect_error);
	}

	$query = "INSERT INTO personnel_info(surname,othername,dob,email,phone,password,institution,std_id,workplace,enumber,district,region,NSS_Number) VALUES ('$surname','$othername','$dob','$email','$phone','$password','$institution','$std_id','$workplace','$enumber','$district','$region','$NSS_Number')";

	if($dbconnection->query($query)==TRUE){
		
	}
	else{
		echo "Error: ". $query. "<br>". $dbconnection->error;
	}


	$dbconnection->close();




?>
	<img src="sent.gif">


	<strong><p style="font-size: 30px; color:#900C3F">Great! Your Account Is Ready</p></strong>

	<div class="login">
		<p>Would you like to Sign In?</p>
		<form method="POST" action="home.html">
			<input type="submit" name="Yes" value= "Yes" class="yes">
			<input type="submit" name="No" value= "No" class="no"  onclick="window.history.back('signup.php'); return false" >
		</form>
	</div>






	</center>

</body>
</html>




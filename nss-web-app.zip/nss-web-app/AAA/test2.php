<!DOCTYPE html>
<html>
<head>
	<title></title>

<style type="text/css">
	.white{
		background-color: white;
	}

	.Error{
		text-decoration:underline;
		color: blue;
	}

		#btSubmit{
			width: 50%;
			height:30px;
			border-radius:20px;
			color:#900C3F;
			border: solid #900C3F 2px;
		}
</style>
</head>
<body>

	<center><div style="padding-bottom:12%">
		<form method="POST">
			<input type="text" name="NSS_Number" placeholder="NSS Number" />
			<input type="submit" name="search" value="Load Form">
		</form><br><br>
		
			
		<table>


			<?php
				$connection = mysqli_connect("localhost", "root", "Lmfao007");
				$db = mysqli_select_db($connection, 'nss_account');



				if(isset($_POST['search'])){
					$NSS_Number = $_POST['NSS_Number'];

					$query = "SELECT * FROM personnel_info WHERE NSS_Number = '$NSS_Number'";
					$query_run = mysqli_query($connection,$query);



					while ($row = mysqli_fetch_array($query_run)) 
					{
						
						?>

						<center>

				<div class="heading">
					<p>GHANA NATIONAL SERVICE SCHEME</p>
					<p>HEADQUATERS</p>
					<p>P.O.BOX46, PRACTICE LUMBLUMB ROAD</p>
					<p>AIRPORT RESIDENTIAL AREA, ACCRA</p>
					<p>TELEPHONE: +233-302-772714</p>
		
				</div><br><br>

				<p style="text-decoration:underline;">MONTHLY REPORT FORM</p><br>
				</center>


					<tr class="white">
						<td>Surname</td>
						<td><?php echo $row['surname']; ?></td>
					</tr>
					<tr>
						<td>Other Name</td>
						<td><?php echo $row['othername']; ?></td>
					</tr>
					<tr class="white">
						<td>NSS_Number</td>
						<td><?php echo $row['NSS_Number']; ?></td>
					</tr>
					<tr>
						<td>Date Of Birth</td>
						<td><?php echo $row['dob']; ?></td>
					</tr>
					<tr class="white">
						<td>Email</td>
						<td><?php echo $row['email']; ?></td>
					</tr>
					<tr>
						<td>Phone</td>
						<td><?php echo $row['phone']; ?></td>
					</tr>
					<tr class="white">
						<td>Institution</td>
						<td><?php echo $row['institution']; ?></td>
					</tr>
					<tr>
						<td>Index Number</td>
						<td><?php echo $row['std_id']; ?></td>
					</tr>
					<tr class="white">
						<td>Workplace</td>
						<td><?php echo $row['workplace']; ?></td>
					</tr>
					<tr>
						<td>District</td>
						<td><?php echo $row['district']; ?></td>
					</tr>
					<tr class="white">
						<td>Region</td>
						<td><?php echo $row['region']; ?></td>
					</tr>
					<tr>
						<td>Ezwich Number</td>
						<td><?php echo $row['enumber']; ?></td>
					</tr>

						<?php
					}

				}
			 ?>
		</table><br>

		<?php include 'load.php'; ?>

	<form method="POST" action="sign.php">
		<input type="checkbox" name="yes" value="yes" onchange="document.getElementById('btSubmit').disabled = !this.checked" required>Click Endorse if you do not have an e-signature to Load/ Want to (Re-)Sign
				<br><br><br>
		<input type="submit" id="btSubmit" value="Endorse" disabled>
	</form></center>

	<a href="" class="Error"><<--Click Here To Report Error-->></a>
	</div>

</body>
</html>



